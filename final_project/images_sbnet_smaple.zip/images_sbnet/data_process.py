 
import numpy as np 
import cv2 
#if you dont have opencv, use skimage or pil
import pickle
import bz2
import os

def save(name, to_save):
	sfile = bz2.BZ2File(name, 'w')
	pickle.dump(to_save, sfile)
	sfile.close()

def load(name):
	sfile = bz2.BZ2File(name, 'rb')
	data = pickle.load(sfile)
	sfile.close()
	return data


def process(DIR, color = 1):
	'''
	DIR is the directory which contains the images
	color = 1 reads in RGB,  color = 0 reads in greyscale 
	'''
	STORE_DIR = "numpy_array/"
	image_list = os.listdir(os.path.join(ROOT_DIR, DIR))
	image_list.sort()
	for i in range(len(image_list)) :
		if i == 0 :
			img = cv2.imread(os.path.join(ROOT_DIR, DIR, image_list[i]), color)
			img_shape = img.shape 
			#torch expects tensors in shape N,C,H,W unlike keras,(N,H,W,C)
			data = np.empty((0, img_shape[2], img_shape[0], img_shape[1]))
			img = np.swapaxes(img, 0, 2)
			img = np.swapaxes(img, 1, 2)
			data = np.concatenate((data, img[np.newaxis, :, :, :]), axis = 0)
		else :
			img =  cv2.imread(os.path.join(ROOT_DIR, DIR, image_list[i]), color)
			img = np.swapaxes(img, 0, 2)
			img = np.swapaxes(img, 1, 2)
			data = np.concatenate((data, img[np.newaxis, :, :, :]), axis = 0)
	save(STORE_DIR + DIR + ".bz2", data)	
	return data

#test = process("no_vehicles_frames")
#print(test.shape)

ROOT_DIR = "images_sbnet"

data_list = os.listdir(ROOT_DIR)
print(data_list)

for i in data_list:
	process(i)


	





# upload the bz2 files to drive and navigate to the place you sotred them 

import numpy as np 
import cv2 
#if you dont have opencv, use skimage or pil
import pickle
import bz2
import os

def save(name, to_save):
	sfile = bz2.BZ2File(name, 'w')
	pickle.dump(to_save, sfile)
	sfile.close()

def load(name):
	sfile = bz2.BZ2File(name, 'rb')
	data = pickle.load(sfile)
	sfile.close()
	return data

data = load("numpy_array/no_vehicles_frames.bz2")

import torch 
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

data_intorch = torch.Tensor(data).to(device)
print(data_intorch.size())
#2 things must be kept in mind, the shape should be N,C,H,W 
#and the model and the data must be on the same device.  
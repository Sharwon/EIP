python benchmark_topleft.py --test=res --arch=resnet-v2
python benchmark_topleft.py --test=res --arch=resnet-50
python benchmark_topleft.py --test=conv --arch=resnet-v2
python benchmark_topleft.py --test=conv --arch=resnet-50
